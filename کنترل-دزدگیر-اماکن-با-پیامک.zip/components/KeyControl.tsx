import React from 'react';
import type { KeyConfig } from '../types';

interface KeyControlProps {
    config: KeyConfig;
    isEditing: boolean;
    onKeyChange: <T extends keyof KeyConfig>(id: number, field: T, value: KeyConfig[T]) => void;
    onSendCommand: (command: string) => void;
}

const KeyControl: React.FC<KeyControlProps> = ({ config, isEditing, onKeyChange, onSendCommand }) => {
    
    return (
        <div className="bg-gray-800 rounded-xl p-4 border border-gray-700 shadow-lg flex flex-col gap-4 transition-all duration-300">
            {isEditing ? (
                 <input
                    type="text"
                    value={config.label}
                    onChange={(e) => onKeyChange(config.id, 'label', e.target.value)}
                    className="w-full bg-gray-700 text-white font-bold text-lg text-center border-b-2 border-purple-500 rounded-t-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
            ) : (
                <h3 className="text-lg font-bold text-center text-gray-200 py-2">{config.label}</h3>
            )}
           
            {isEditing && (
                <div className="flex flex-col gap-3">
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">دستور روشن</label>
                         <input
                            type="text"
                            value={config.onCommand}
                            onChange={(e) => onKeyChange(config.id, 'onCommand', e.target.value)}
                            className="w-full bg-gray-900 text-white border border-gray-600 rounded-md p-2 focus:ring-1 focus:ring-green-500 focus:border-green-500 transition text-left text-sm"
                            dir="ltr"
                        />
                    </div>
                     <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">دستور خاموش</label>
                         <input
                            type="text"
                            value={config.offCommand}
                            onChange={(e) => onKeyChange(config.id, 'offCommand', e.target.value)}
                            className="w-full bg-gray-900 text-white border border-gray-600 rounded-md p-2 focus:ring-1 focus:ring-red-500 focus:border-red-500 transition text-left text-sm"
                            dir="ltr"
                        />
                    </div>
                </div>
            )}
            
            <div className={`grid grid-cols-2 gap-3 ${isEditing ? 'mt-2' : 'mt-auto'}`}>
                <button 
                    onClick={() => onSendCommand(config.onCommand)}
                    className="w-full px-4 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md transition-all duration-300 transform hover:scale-105 shadow-md flex items-center justify-center gap-2"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
                    </svg>
                    <span>روشن</span>
                </button>
                <button 
                    onClick={() => onSendCommand(config.offCommand)}
                    className="w-full px-4 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-md transition-all duration-300 transform hover:scale-105 shadow-md flex items-center justify-center gap-2"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                    </svg>
                    <span>خاموش</span>
                </button>
            </div>
        </div>
    );
};

export default KeyControl;
