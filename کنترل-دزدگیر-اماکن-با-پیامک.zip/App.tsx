import React, { useState, useEffect, useCallback } from 'react';
import { KeyConfig, AppConfig } from './types';
import KeyControl from './components/KeyControl';

const HouseIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-cyan-400" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
    </svg>
);

const getDefaultConfig = (): AppConfig => ({
    phoneNumber: '',
    keys: Array.from({ length: 6 }, (_, i) => ({
        id: i + 1,
        label: `کلید ${i + 1}`,
        onCommand: `ON${i + 1}`,
        offCommand: `OFF${i + 1}`,
    })),
    sirenCommand: 'SIREN_OFF',
});


function App() {
    const [config, setConfig] = useState<AppConfig>(getDefaultConfig());
    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        try {
            const savedConfig = localStorage.getItem('alarmConfigV1');
            if (savedConfig) {
                const parsedConfig = JSON.parse(savedConfig);
                // Basic validation
                if (parsedConfig.phoneNumber && parsedConfig.keys && parsedConfig.sirenCommand) {
                    setConfig(parsedConfig);
                } else {
                     setConfig(getDefaultConfig());
                }
            }
        } catch (error) {
            console.error("Failed to load or parse config from localStorage:", error);
            setConfig(getDefaultConfig());
        }
    }, []);

    useEffect(() => {
        try {
            localStorage.setItem('alarmConfigV1', JSON.stringify(config));
        } catch (error) {
            console.error("Failed to save config to localStorage:", error);
        }
    }, [config]);

    const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setConfig(prev => ({ ...prev, phoneNumber: e.target.value }));
    };

    const handleKeyChange = <T extends keyof KeyConfig>(id: number, field: T, value: KeyConfig[T]) => {
        setConfig(prev => ({
            ...prev,
            keys: prev.keys.map(key => key.id === id ? { ...key, [field]: value } : key)
        }));
    };

    const handleSirenCommandChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setConfig(prev => ({ ...prev, sirenCommand: e.target.value }));
    };

    const handleSendCommand = useCallback((command: string) => {
        if (!config.phoneNumber) {
            alert('لطفاً ابتدا شماره تلفن دزدگیر را وارد کنید.');
            return;
        }
        if (!command) {
            alert('دستور ارسالی خالی است. لطفاً یک دستور معتبر وارد کنید.');
            return;
        }
        const smsLink = `sms:${config.phoneNumber}?body=${encodeURIComponent(command)}`;
        window.location.href = smsLink;
    }, [config.phoneNumber]);

    return (
        <div className="min-h-screen bg-gray-900 text-white font-sans p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <header className="text-center mb-8 flex flex-col items-center gap-4">
                    <HouseIcon />
                    <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                        دزدگیر اماکن
                    </h1>
                    <p className="text-gray-400">پنل کنترل از راه دور با پیامک</p>
                </header>

                <main>
                    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 mb-8 border border-gray-700 shadow-lg">
                        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
                             <div className="flex-grow w-full">
                                <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-300 mb-2">
                                    شماره تلفن دزدگیر
                                </label>
                                <input
                                    type="tel"
                                    id="phoneNumber"
                                    value={config.phoneNumber}
                                    onChange={handlePhoneNumberChange}
                                    placeholder="مثال: 09123456789"
                                    className="w-full bg-gray-700 text-white border border-gray-600 rounded-md p-3 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition text-left"
                                    dir="ltr"
                                />
                            </div>
                            <div className="w-full sm:w-auto pt-4 sm:pt-0">
                                <button
                                    onClick={() => setIsEditing(!isEditing)}
                                    className="w-full sm:w-auto mt-auto px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 rounded-md transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                      <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                                      <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
                                    </svg>
                                    <span>{isEditing ? 'ذخیره و پایان ویرایش' : 'ویرایش کلیدها'}</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                        {config.keys.map(key => (
                            <KeyControl
                                key={key.id}
                                config={key}
                                onKeyChange={handleKeyChange}
                                onSendCommand={handleSendCommand}
                                isEditing={isEditing}
                            />
                        ))}
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 shadow-lg">
                        <h3 className="text-xl font-bold text-amber-400 mb-4">کنترل آژیر</h3>
                        {isEditing && (
                            <div className="mb-4">
                                <label htmlFor="sirenCommand" className="block text-sm font-medium text-gray-300 mb-2">
                                    دستور قطع آژیر
                                </label>
                                <input
                                    type="text"
                                    id="sirenCommand"
                                    value={config.sirenCommand}
                                    onChange={handleSirenCommandChange}
                                    className="w-full bg-gray-700 text-white border border-gray-600 rounded-md p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition text-left"
                                    dir="ltr"
                                />
                            </div>
                        )}
                        <button
                            onClick={() => handleSendCommand(config.sirenCommand)}
                            className="w-full px-6 py-4 bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold rounded-md transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.858 5.858a3 3 0 10-4.242 4.243L12 21l10.385-10.893a3 3 0 10-4.242-4.243L12 10.172 5.858 5.858z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9l-6 6-6-6" transform="rotate(-45 12 12)" />
                            </svg>
                            <span>قطع آژیر</span>
                        </button>
                    </div>

                </main>

                <footer className="text-center mt-12 py-4 border-t border-gray-800">
                    <p className="text-gray-500 text-sm">ساخته شده توسط امیر مهدی نوری</p>
                </footer>
            </div>
        </div>
    );
}

export default App;
