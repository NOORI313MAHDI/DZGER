export interface KeyConfig {
  id: number;
  label: string;
  onCommand: string;
  offCommand: string;
}

export interface AppConfig {
  phoneNumber: string;
  keys: KeyConfig[];
  sirenCommand: string;
}
