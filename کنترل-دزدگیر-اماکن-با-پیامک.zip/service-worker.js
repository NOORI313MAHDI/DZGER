const CACHE_NAME = 'alarm-control-cache-v1';
// لیست فایل‌های اصلی برنامه که باید کش شوند تا به صورت آفلاین در دسترس باشند.
const urlsToCache = [
  './',
  './index.html',
  './manifest.webmanifest'
];

// رویداد نصب سرویس ورکر: فایل‌های اصلی را در حافظه پنهان (cache) ذخیره می‌کند.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// رویداد fetch: درخواست‌ها را رهگیری کرده و در صورت وجود در کش، نسخه ذخیره شده را برمی‌گرداند.
// این باعث می‌شود برنامه به سرعت و به صورت آفلاین بارگذاری شود.
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          return response; // بازگرداندن از کش
        }
        return fetch(event.request); // در غیر این صورت، درخواست از شبکه
      }
    )
  );
});

// رویداد فعال‌سازی: کش‌های قدیمی را پاک می‌کند تا برنامه همیشه به‌روز بماند.
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
